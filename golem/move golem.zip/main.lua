function love.load()

-- set up some fonts
	small = love.graphics.newFont(25)
	medium = love.graphics.newFont(45)
	large = love.graphics.newFont(72)

--set up some colors
	red = {255,0,0}
	green = {0,255,0}
	blue = {0,0,255}

-- load picture
	golem = love.graphics.newImage("golem.png")
	golemX = 100
	golemY = 100


end



function love.update()
	if love.keyboard.isDown("right") then
		golemX = golemX + 10
			if golemX >= 600 then
				golemX = 600
			end
	end

	if love.keyboard.isDown("left") then
		golemX = golemX - 10
			if golemX <= 50 then
				golemX = 50
			end
	end


end



function love.draw()
	love.window.setTitle("Golem move: 2 directions")
	love.graphics.setFont(small)
	-- text, xpos,ypos
	love.graphics.setColor(0,255,255)
	love.graphics.print("Wow Such Golem", 20, 10)

	love.graphics.setColor(255,255,255)
		love.graphics.draw(golem, golemX, golemY)
		
		
		love.graphics.rectangle("fill", 10, 250, 10, 50)






end
