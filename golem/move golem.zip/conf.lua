function love.conf(t)
	t.screen.width = 900
	t.screen.height = 900
	t.title= "this config is working"
end
